
public class MyApp {

	public static void main(String[] args) {
		System.out.println("This is my first JAVA Program");
		System.out.println("This is my first time using Eclipse IDE");

	}

}
